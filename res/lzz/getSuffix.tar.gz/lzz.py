import os
ffs=os.listdir('.')
xls=[xl for xl in ffs if os.path.isdir(xl)]
suffixs=[os.path.splitext(suffix)[0] for suffix in xls]
os.mkdir('lzz')
os.chdir('lzz')
for suffix in xls:
    with open(xl+'.xls','w+') as ff:
        pass

